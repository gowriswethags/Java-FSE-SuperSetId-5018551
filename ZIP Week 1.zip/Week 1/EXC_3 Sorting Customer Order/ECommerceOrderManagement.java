import java.util.Scanner;

class Order {
    private String orderId;
    private String customerName;
    private double totalPrice;

    public Order(String orderId, String customerName, double totalPrice) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.totalPrice = totalPrice;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderId='" + orderId + '\'' +
                ", customerName='" + customerName + '\'' +
                ", totalPrice=" + totalPrice +
                '}';
    }
}

public class ECommerceOrderManagement {
    private Order[] orders;
    private int orderCount;

    public ECommerceOrderManagement(int size) {
        orders = new Order[size];
        orderCount = 0;
    }

    public void addOrder(Order order) {
        if (orderCount < orders.length) {
            orders[orderCount++] = order;
        } else {
            System.out.println("Order list is full, cannot add more orders.");
        }
    }

    public void updateOrder(String orderId, Order updatedOrder) {
        for (int i = 0; i < orderCount; i++) {
            if (orders[i].getOrderId().equalsIgnoreCase(orderId)) {
                orders[i] = updatedOrder;
                return;
            }
        }
        System.out.println("Order not found.");
    }

    public void deleteOrder(String orderId) {
        for (int i = 0; i < orderCount; i++) {
            if (orders[i].getOrderId().equalsIgnoreCase(orderId)) {
                orders[i] = orders[--orderCount]; // Replace with last order and decrease count
                orders[orderCount] = null; // Avoid memory leak
                return;
            }
        }
        System.out.println("Order not found.");
    }

    public void displayOrders() {
        for (int i = 0; i < orderCount; i++) {
            System.out.println(orders[i]);
        }
    }

    public void bubbleSort() {
        for (int i = 0; i < orderCount - 1; i++) {
            for (int j = 0; j < orderCount - i - 1; j++) {
                if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice()) {
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }

    private int partition(Order[] orders, int low, int high) {
        double pivot = orders[high].getTotalPrice();
        int i = low - 1; // Index of smaller element
        for (int j = low; j < high; j++) {
            if (orders[j].getTotalPrice() < pivot) {
                i++;
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;

        return i + 1;
    }

    public void quickSort(int low, int high) {
        if (low < high) {
            int pi = partition(orders, low, high);

            quickSort(low, pi - 1);
            quickSort(pi + 1, high);
        }
    }

    private static Order getOrderDetailsFromUser(Scanner scanner) {
        System.out.println("Enter order ID: ");
        String orderId = scanner.nextLine();
        System.out.println("Enter customer name: ");
        String customerName = scanner.nextLine();
        System.out.println("Enter total price: ");
        double totalPrice = Double.parseDouble(scanner.nextLine());

        return new Order(orderId, customerName, totalPrice);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ECommerceOrderManagement platform = new ECommerceOrderManagement(100);

        String command;

        do {
            System.out.println("Enter a command (add, update, delete, display, sort, exit): ");
            command = scanner.nextLine();

            switch (command.toLowerCase()) {
                case "add":
                    Order newOrder = getOrderDetailsFromUser(scanner);
                    platform.addOrder(newOrder);
                    break;
                case "update":
                    System.out.println("Enter the order ID to update: ");
                    String updateId = scanner.nextLine();
                    Order updatedOrder = getOrderDetailsFromUser(scanner);
                    platform.updateOrder(updateId, updatedOrder);
                    break;
                case "delete":
                    System.out.println("Enter the order ID to delete: ");
                    String deleteId = scanner.nextLine();
                    platform.deleteOrder(deleteId);
                    break;
                case "display":
                    platform.displayOrders();
                    break;
                case "sort":
                    System.out.println("Choose sorting method: 1. Bubble Sort 2. Quick Sort \nEnter as number ");
                    int choice = Integer.parseInt(scanner.nextLine());
                    if (choice == 1) {
                        platform.bubbleSort();
                        System.out.println("Orders sorted by Bubble Sort:");
                    } else if (choice == 2) {
                        platform.quickSort(0, platform.orderCount - 1);
                        System.out.println("Orders sorted by Quick Sort:");
                    } else {
                        System.out.println("Invalid choice.");
                        break;
                    }
                    platform.displayOrders();
                    break;
                case "exit":
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid command.");
            }
        } while (!command.equalsIgnoreCase("exit"));

        scanner.close();
    }
}
