import java.util.Scanner;

class Employee {
    private String employeeId;
    private String name;
    private String position;
    private double salary;

    public Employee(String employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeeId='" + employeeId + '\'' +
                ", name='" + name + '\'' +
                ", position='" + position + '\'' +
                ", salary=" + salary +
                '}';
    }
}


public class EmployeeManagementSystem {
    private Employee[] employees;
    private int employeeCount;

    public EmployeeManagementSystem(int size) {
        employees = new Employee[size];
        employeeCount = 0;
    }

    public void addEmployee(Employee employee) {
        if (employeeCount < employees.length) {
            employees[employeeCount++] = employee;
        } else {
            System.out.println("Employee list is full, cannot add more employees.");
        }
    }

    public Employee searchEmployee(String employeeId) {
        for (int i = 0; i < employeeCount; i++) {
            if (employees[i].getEmployeeId().equalsIgnoreCase(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    public void traverseEmployees() {
        for (int i = 0; i < employeeCount; i++) {
            System.out.println(employees[i]);
        }
    }

    public void deleteEmployee(String employeeId) {
        for (int i = 0; i < employeeCount; i++) {
            if (employees[i].getEmployeeId().equalsIgnoreCase(employeeId)) {
                employees[i] = employees[--employeeCount]; // Replace with last employee and decrease count
                employees[employeeCount] = null; // Avoid memory leak
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    private static Employee getEmployeeDetailsFromUser(Scanner scanner) {
        System.out.println("Enter employee ID: ");
        String employeeId = scanner.nextLine();
        System.out.println("Enter name: ");
        String name = scanner.nextLine();
        System.out.println("Enter position: ");
        String position = scanner.nextLine();
        System.out.println("Enter salary: ");
        double salary = Double.parseDouble(scanner.nextLine());

        return new Employee(employeeId, name, position, salary);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EmployeeManagementSystem system = new EmployeeManagementSystem(100);

        String command;

        do {
            System.out.println("Enter a command (add, search, traverse, delete, exit): ");
            command = scanner.nextLine();

            switch (command.toLowerCase()) {
                case "add":
                    Employee newEmployee = getEmployeeDetailsFromUser(scanner);
                    system.addEmployee(newEmployee);
                    break;
                case "search":
                    System.out.println("Enter the employee ID to search: ");
                    String searchId = scanner.nextLine();
                    Employee foundEmployee = system.searchEmployee(searchId);
                    if (foundEmployee != null) {
                        System.out.println("Employee found: " + foundEmployee);
                    } else {
                        System.out.println("Employee not found.");
                    }
                    break;
                case "traverse":
                    system.traverseEmployees();
                    break;
                case "delete":
                    System.out.println("Enter the employee ID to delete: ");
                    String deleteId = scanner.nextLine();
                    system.deleteEmployee(deleteId);
                    break;
                case "exit":
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid command.");
            }
        } while (!command.equalsIgnoreCase("exit"));

        scanner.close();
    }
}
