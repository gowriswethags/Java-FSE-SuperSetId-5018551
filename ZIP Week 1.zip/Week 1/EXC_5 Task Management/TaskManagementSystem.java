import java.util.Scanner;

class Task {
    private String taskId;
    private String taskName;
    private String status;

    public Task(String taskId, String taskName, String status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Task{" +
                "taskId='" + taskId + '\'' +
                ", taskName='" + taskName + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}



class TaskNode {
    Task task;
    TaskNode next;

    public TaskNode(Task task) {
        this.task = task;
        this.next = null;
    }
}

class TaskLinkedList {
    private TaskNode head;

    public TaskLinkedList() {
        this.head = null;
    }

    public void addTask(Task task) {
        TaskNode newNode = new TaskNode(task);
        if (head == null) {
            head = newNode;
        } else {
            TaskNode current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public Task searchTask(String taskId) {
        TaskNode current = head;
        while (current != null) {
            if (current.task.getTaskId().equalsIgnoreCase(taskId)) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

    public void traverseTasks() {
        TaskNode current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    public void deleteTask(String taskId) {
        if (head == null) {
            System.out.println("Task list is empty.");
            return;
        }
        if (head.task.getTaskId().equalsIgnoreCase(taskId)) {
            head = head.next;
            return;
        }
        TaskNode current = head;
        TaskNode prev = null;
        while (current != null && !current.task.getTaskId().equalsIgnoreCase(taskId)) {
            prev = current;
            current = current.next;
        }
        if (current == null) {
            System.out.println("Task not found.");
        } else {
            prev.next = current.next;
        }
    }
}

public class TaskManagementSystem {
    private static Task getTaskDetailsFromUser(Scanner scanner) {
        System.out.println("Enter task ID: ");
        String taskId = scanner.nextLine();
        System.out.println("Enter task name: ");
        String taskName = scanner.nextLine();
        System.out.println("Enter status: ");
        String status = scanner.nextLine();

        return new Task(taskId, taskName, status);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TaskLinkedList taskList = new TaskLinkedList();

        String command;

        do {
            System.out.println("Enter a command (add, search, traverse, delete, exit): ");
            command = scanner.nextLine();

            switch (command.toLowerCase()) {
                case "add":
                    Task newTask = getTaskDetailsFromUser(scanner);
                    taskList.addTask(newTask);
                    break;
                case "search":
                    System.out.println("Enter the task ID to search: ");
                    String searchId = scanner.nextLine();
                    Task foundTask = taskList.searchTask(searchId);
                    if (foundTask != null) {
                        System.out.println("Task found: " + foundTask);
                    } else {
                        System.out.println("Task not found.");
                    }
                    break;
                case "traverse":
                    taskList.traverseTasks();
                    break;
                case "delete":
                    System.out.println("Enter the task ID to delete: ");
                    String deleteId = scanner.nextLine();
                    taskList.deleteTask(deleteId);
                    break;
                case "exit":
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid command.");
            }
        } while (!command.equalsIgnoreCase("exit"));

        scanner.close();
    }
}
