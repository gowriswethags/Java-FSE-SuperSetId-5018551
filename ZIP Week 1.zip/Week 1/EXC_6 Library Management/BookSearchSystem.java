import java.util.Arrays;
import java.util.Scanner;

class Book {
    private String bookId;
    private String title;
    private String author;

    public Book(String bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    @Override
    public String toString() {
        return "Book{" +
                "bookId='" + bookId + '\'' +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                '}';
    }
}



public class BookSearchSystem {
    
    public static int linearSearch(Book[] books, String title) {
        for (int i = 0; i < books.length; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return i;
            }
        }
        return -1; // Not found
    }

    public static int binarySearch(Book[] books, String title) {
        int left = 0;
        int right = books.length - 1;
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            if (books[mid].getTitle().equalsIgnoreCase(title)) {
                return mid;
            }
            
            if (books[mid].getTitle().compareToIgnoreCase(title) < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        
        return -1; // Not found
    }
    
    private static Book[] getBooksFromUser(Scanner scanner) {
        System.out.println("Enter number of books: ");
        int n = Integer.parseInt(scanner.nextLine());
        Book[] books = new Book[n];
        
        for (int i = 0; i < n; i++) {
            System.out.println("Enter book ID: ");
            String bookId = scanner.nextLine();
            System.out.println("Enter book title: ");
            String title = scanner.nextLine();
            System.out.println("Enter book author: ");
            String author = scanner.nextLine();
            
            books[i] = new Book(bookId, title, author);
        }
        
        return books;
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        Book[] books = getBooksFromUser(scanner);
        
        System.out.println("Enter the title of the book to search for: ");
        String titleToSearch = scanner.nextLine();
        
        System.out.println("Performing Linear Search...");
        int linearIndex = linearSearch(books, titleToSearch);
        if (linearIndex != -1) {
            System.out.println("Book found: " + books[linearIndex]);
        } else {
            System.out.println("Book not found.");
        }
        
        Arrays.sort(books, (b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));
        
        System.out.println("Performing Binary Search...");
        int binaryIndex = binarySearch(books, titleToSearch);
        if (binaryIndex != -1) {
            System.out.println("Book found: " + books[binaryIndex]);
        } else {
            System.out.println("Book not found.");
        }
        
        scanner.close();
    }
}
