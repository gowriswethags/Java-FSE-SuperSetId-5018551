import java.util.Arrays;
import java.util.Scanner;

class Product {
    private String productId;
    private String productName;
    private String category;

    public Product(String productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }

    // Getters and Setters
    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productId='" + productId + '\'' +
                ", productName='" + productName + '\'' +
                ", category='" + category + '\'' +
                '}';
    }
}

public class ECommercePlatform {

    private Product[] products;
    private int productCount;

    public ECommercePlatform(int size) {
        products = new Product[size];
        productCount = 0;
    }

    public void addProduct(Product product) {
        if (productCount < products.length) {
            products[productCount++] = product;
        } else {
            System.out.println("Inventory is full, cannot add more products.");
        }
    }

    public void updateProduct(String productId, Product updatedProduct) {
        for (int i = 0; i < productCount; i++) {
            if (products[i].getProductId().equalsIgnoreCase(productId)) {
                products[i] = updatedProduct;
                return;
            }
        }
        System.out.println("Product not found.");
    }

    public void deleteProduct(String productId) {
        for (int i = 0; i < productCount; i++) {
            if (products[i].getProductId().equalsIgnoreCase(productId)) {
                products[i] = products[--productCount]; // Replace with last product and decrease count
                products[productCount] = null; // Avoid memory leak
                return;
            }
        }
        System.out.println("Product not found.");
    }

    public void displayProducts() {
        for (int i = 0; i < productCount; i++) {
            System.out.println(products[i]);
        }
    }

    public Product linearSearch(String productName) {
        for (Product product : products) {
            if (product != null && product.getProductName().equalsIgnoreCase(productName)) {
                return product;
            }
        }
        return null;
    }

    public Product binarySearch(String productName) {
        Arrays.sort(products, 0, productCount, (p1, p2) -> p1.getProductName().compareToIgnoreCase(p2.getProductName()));
        int left = 0;
        int right = productCount - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int result = products[mid].getProductName().compareToIgnoreCase(productName);
            if (result == 0) {
                return products[mid];
            } else if (result < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    private static Product getProductDetailsFromUser(Scanner scanner) {
        System.out.println("Enter product ID: ");
        String productId = scanner.nextLine();
        System.out.println("Enter product name: ");
        String productName = scanner.nextLine();
        System.out.println("Enter product category: ");
        String category = scanner.nextLine();

        return new Product(productId, productName, category);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ECommercePlatform platform = new ECommercePlatform(100);

        String command;

        do {
            System.out.println("Enter a command (add, update, delete, display, search, exit): ");
            command = scanner.nextLine();

            switch (command.toLowerCase()) {
                case "add":
                    Product newProduct = getProductDetailsFromUser(scanner);
                    platform.addProduct(newProduct);
                    break;
                case "update":
                    System.out.println("Enter the product ID to update: ");
                    String updateId = scanner.nextLine();
                    Product updatedProduct = getProductDetailsFromUser(scanner);
                    platform.updateProduct(updateId, updatedProduct);
                    break;
                case "delete":
                    System.out.println("Enter the product ID to delete: ");
                    String deleteId = scanner.nextLine();
                    platform.deleteProduct(deleteId);
                    break;
                case "display":
                    platform.displayProducts();
                    break;
                case "search":
                    System.out.println("Enter the product name to search: ");
                    String productName = scanner.nextLine();
                    System.out.println("Choose search method: 1. Linear Search 2. Binary Search \nEnter as number");
                    int choice = Integer.parseInt(scanner.nextLine());
                    Product result = null;
                    if (choice == 1) {
                        result = platform.linearSearch(productName);
                    } else if (choice == 2) {
                        result = platform.binarySearch(productName);
                    } else {
                        System.out.println("Invalid choice.");
                    }
                    if (result != null) {
                        System.out.println("Product found: " + result);
                    } else {
                        System.out.println("Product not found.");
                    }
                    break;
                case "exit":
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid command.");
            }
        } while (!command.equalsIgnoreCase("exit"));

        scanner.close();
    }
}
