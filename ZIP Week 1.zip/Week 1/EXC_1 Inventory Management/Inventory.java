import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Inventory {

    private Map<String, Product> products;

    public Inventory() {
        this.products = new HashMap<>();
    }

    public void addProduct(Product product) {
        products.put(product.getProductId(), product);
    }

    public void updateProduct(String productId, Product product) {
        if (products.containsKey(productId)) {
            products.put(productId, product);
        } else {
            System.out.println("Product not found");
        }
    }

    public void deleteProduct(String productId) {
        if (products.containsKey(productId)) {
            products.remove(productId);
        } else {
            System.out.println("Product not found");
        }
    }

    public Product getProduct(String productId) {
        return products.get(productId);
    }

    public void displayInventory() {
        for (Product product : products.values()) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        Scanner scanner = new Scanner(System.in);
        String command;

        do {
            System.out.println("Enter a command (add, update, delete, display, exit): ");
            command = scanner.nextLine();

            switch (command.toLowerCase()) {
                case "add":
                    Product newProduct = getProductDetailsFromUser(scanner);
                    inventory.addProduct(newProduct);
                    break;
                case "update":
                    System.out.println("Enter the product ID to update: ");
                    String updateId = scanner.nextLine();
                    Product updatedProduct = getProductDetailsFromUser(scanner);
                    inventory.updateProduct(updateId, updatedProduct);
                    break;
                case "delete":
                    System.out.println("Enter the product ID to delete: ");
                    String deleteId = scanner.nextLine();
                    inventory.deleteProduct(deleteId);
                    break;
                case "display":
                    inventory.displayInventory();
                    break;
                case "exit":
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid command.");
            }
        } while (!command.equalsIgnoreCase("exit"));

        scanner.close();
    }

    private static Product getProductDetailsFromUser(Scanner scanner) {
        System.out.println("Enter product ID: ");
        String productId = scanner.nextLine();
        System.out.println("Enter product name: ");
        String productName = scanner.nextLine();
        System.out.println("Enter product quantity: ");
        int quantity = Integer.parseInt(scanner.nextLine());
        System.out.println("Enter product price: ");
        double price = Double.parseDouble(scanner.nextLine());

        return new Product(productId, productName, quantity, price);
    }
}

class Product {
    private String productId;
    private String productName;
    private int quantity;
    private double price;

    public Product(String productId, String productName, int quantity, double price) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    // Getters and Setters
    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productId='" + productId + '\'' +
                ", productName='" + productName + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                '}';
    }
}
