public class CreditCardPayment implements PaymentStrategy {
    public CreditCardPayment(String cardNumber, String cardHolderName) {
    }

    @Override
    public void pay(double amount) {
        System.out.println("Processing credit card payment of Rs." + amount);
        // Logic for processing credit card payment
        System.out.println("Payment of Rs." + amount + " completed using Credit Card.");
    }
}
