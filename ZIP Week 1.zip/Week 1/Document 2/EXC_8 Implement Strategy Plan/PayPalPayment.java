public class PayPalPayment implements PaymentStrategy {
    public PayPalPayment(String email) {
    }

    @Override
    public void pay(double amount) {
        System.out.println("Processing PayPal payment of Rs." + amount);
        // Logic for processing PayPal payment
        System.out.println("Payment of Rs." + amount + " completed using PayPal.");
    }
}
