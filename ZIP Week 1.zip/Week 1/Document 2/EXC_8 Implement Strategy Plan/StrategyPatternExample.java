import java.util.Scanner;

public class StrategyPatternExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PaymentContext paymentContext = new PaymentContext();
        String userChoice;

        do {
            System.out.println("\nMenu:");
            System.out.println("1. Pay with Credit Card");
            System.out.println("2. Pay with PayPal");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            userChoice = scanner.nextLine();

            switch (userChoice) {
                case "1":
                    System.out.print("Enter credit card number: ");
                    String cardNumber = scanner.nextLine();
                    System.out.print("Enter card holder name: ");
                    String cardHolderName = scanner.nextLine();
                    System.out.print("Enter amount to pay: ");
                    double creditCardAmount = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline

                    PaymentStrategy creditCardPayment = new CreditCardPayment(cardNumber, cardHolderName);
                    paymentContext.setPaymentStrategy(creditCardPayment);
                    paymentContext.executePayment(creditCardAmount);
                    break;

                case "2":
                    System.out.print("Enter PayPal email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter amount to pay: ");
                    double paypalAmount = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline

                    PaymentStrategy payPalPayment = new PayPalPayment(email);
                    paymentContext.setPaymentStrategy(payPalPayment);
                    paymentContext.executePayment(paypalAmount);
                    break;

                case "3":
                    System.out.println("Exiting the program.");
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (!userChoice.equals("3"));

        scanner.close();
    }
}
