import java.util.Scanner;

public class DecoratorPatternExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String userChoice;

        do {
            // Create the base Email Notifier
            Notifier baseNotifier = new EmailNotifier();

            // Ask user which decorators they want
            System.out.println("Select notification channels (comma-separated):");
            System.out.println("1. SMS");
            System.out.println("2. Slack");
            System.out.print("Enter your choices (e.g., 1,2): ");
            String[] choices = scanner.nextLine().split(",");

            // Add chosen decorators
            Notifier notifier = baseNotifier;
            for (String choice : choices) {
                switch (choice.trim()) {
                    case "1":
                        notifier = new SMSNotifierDecorator(notifier);
                        break;
                    case "2":
                        notifier = new SlackNotifierDecorator(notifier);
                        break;
                    default:
                        System.out.println("Invalid choice: " + choice);
                }
            }

            // Get the message to send
            System.out.print("Enter the message to send: ");
            String message = scanner.nextLine();

            // Send the notification through the selected channels
            notifier.send(message);

            // Ask if the user wants to send another notification
            System.out.print("Do you want to send another notification? (yes/no): ");
            userChoice = scanner.nextLine();

        } while (userChoice.equalsIgnoreCase("yes"));

        System.out.println("Exiting the program.");
        scanner.close();
    }
}
