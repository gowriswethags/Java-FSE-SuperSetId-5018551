import java.util.Scanner;

public class ProxyPatternExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String userChoice;

        do {
            // Ask user for the image filename
            System.out.print("Enter the filename of the image to display: ");
            String filename = scanner.nextLine();

            // Create ProxyImage for the specified file
            Image proxyImage = new ProxyImage(filename);

            // Display the image
            // The image will be loaded from the server on the first call to display()
            System.out.println("First call to display the image:");
            proxyImage.display();

            // Display the image again
            // This time, the image should not be loaded from the server again
            System.out.println("Second call to display the image:");
            proxyImage.display();

            // Ask if the user wants to display another image
            System.out.print("Do you want to display another image? (yes/no): ");
            userChoice = scanner.nextLine();

        } while (userChoice.equalsIgnoreCase("yes"));

        System.out.println("Exiting the program.");
        scanner.close();
    }
}
