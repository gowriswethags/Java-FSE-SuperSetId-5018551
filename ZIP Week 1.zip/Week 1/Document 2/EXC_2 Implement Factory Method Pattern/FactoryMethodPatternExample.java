import java.util.Scanner;

public class FactoryMethodPatternExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DocumentFactory factory = null;
        String documentType;

        while (true) {
            System.out.println("Enter the type of document you want to create (word/pdf/excel) or type 'exit' to quit:");
            documentType = scanner.nextLine().trim().toLowerCase();

            if (documentType.equals("exit")) {
                System.out.println("Exiting the program.");
                break;
            }

            switch (documentType) {
                case "word":
                    factory = new WordDocumentFactory();
                    break;
                case "pdf":
                    factory = new PdfDocumentFactory();
                    break;
                case "excel":
                    factory = new ExcelDocumentFactory();
                    break;
                default:
                    System.out.println("Invalid document type entered. Please try again.");
                    continue;
            }

            if (factory != null) {
                Document document = factory.createDocument();
                document.open();
                document.save();
                document.close();
            }
        }

        scanner.close();
    }
}
