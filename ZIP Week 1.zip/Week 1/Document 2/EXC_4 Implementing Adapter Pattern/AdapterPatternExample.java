import java.util.Scanner;

public class AdapterPatternExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String userChoice="yes";

        do {
            System.out.println("Choose a payment gateway:");
            System.out.println("1. PayPal");
            System.out.println("2. Stripe");
            System.out.print("Enter your choice (1 or 2): ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline

            PaymentProcessor paymentProcessor = null;

            switch (choice) {
                case 1:
                    paymentProcessor = new PayPalAdapter(new PayPalGateway());
                    break;
                case 2:
                    paymentProcessor = new StripeAdapter(new StripeGateway());
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1 or 2.");
                    continue;
            }

            System.out.print("Enter the amount to process: Rs.");
            double amount = scanner.nextDouble();
            scanner.nextLine();  // Consume the newline

            paymentProcessor.processPayment(amount);

            System.out.print("Do you want to process another payment? (yes/no): ");
            userChoice = scanner.nextLine();

        } while (userChoice.equalsIgnoreCase("yes"));

        System.out.println("Exiting the program.");
        scanner.close();
    }
}