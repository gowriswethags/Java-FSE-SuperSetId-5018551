import java.util.Scanner;

public class CommandPatternExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Light light = new Light();
        RemoteControl remoteControl = new RemoteControl();

        // Create command objects
        Command lightOn = new LightOnCommand(light);
        Command lightOff = new LightOffCommand(light);

        String userChoice;

        do {
            System.out.println("\nMenu:");
            System.out.println("1. Turn ON the light");
            System.out.println("2. Turn OFF the light");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            userChoice = scanner.nextLine();

            switch (userChoice) {
                case "1":
                    remoteControl.setCommand(lightOn);
                    remoteControl.pressButton();
                    break;

                case "2":
                    remoteControl.setCommand(lightOff);
                    remoteControl.pressButton();
                    break;

                case "3":
                    System.out.println("Exiting the program.");
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (!userChoice.equals("3"));

        scanner.close();
    }
}
