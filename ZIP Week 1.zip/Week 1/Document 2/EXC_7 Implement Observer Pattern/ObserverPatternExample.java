import java.util.Scanner;

public class ObserverPatternExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StockMarket stockMarket = new StockMarket("AAPL", 150.00);

        // Create observer instances
        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();

        String userChoice;

        do {
            System.out.println("\nMenu:");
            System.out.println("1. Register MobileApp");
            System.out.println("2. Register WebApp");
            System.out.println("3. Deregister MobileApp");
            System.out.println("4. Deregister WebApp");
            System.out.println("5. Update Stock Price");
            System.out.println("6. Display Current Stock Price");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            userChoice = scanner.nextLine();

            switch (userChoice) {
                case "1":
                    stockMarket.registerObserver(mobileApp);
                    System.out.println("MobileApp registered.");
                    break;
                case "2":
                    stockMarket.registerObserver(webApp);
                    System.out.println("WebApp registered.");
                    break;
                case "3":
                    stockMarket.deregisterObserver(mobileApp);
                    System.out.println("MobileApp deregistered.");
                    break;
                case "4":
                    stockMarket.deregisterObserver(webApp);
                    System.out.println("WebApp deregistered.");
                    break;
                case "5":
                    System.out.print("Enter new stock price: ");
                    double newPrice = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline
                    stockMarket.setStockPrice(newPrice);
                    break;
                case "6":
                    System.out.println("Current stock price: Rs." + stockMarket.getStockPrice());
                    break;
                case "7":
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (!userChoice.equals("7"));

        scanner.close();
    }
}
