import java.util.Scanner;

public class BuilderPatternExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String userChoice;

        do {
            System.out.println("Enter CPU: ");
            String CPU = scanner.nextLine();

            System.out.println("Enter RAM: ");
            String RAM = scanner.nextLine();

            System.out.println("Enter Storage: ");
            String storage = scanner.nextLine();

            Computer.ComputerBuilder builder = new Computer.ComputerBuilder(CPU, RAM, storage);

            System.out.println("Do you want to add a GPU? (yes/no): ");
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
                System.out.println("Enter GPU: ");
                String GPU = scanner.nextLine();
                builder.setGPU(GPU);
            }

            System.out.println("Do you want to add a Sound Card? (yes/no): ");
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
                System.out.println("Enter Sound Card: ");
                String soundCard = scanner.nextLine();
                builder.setSoundCard(soundCard);
            }

            System.out.println("Do you want to add a Network Card? (yes/no): ");
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
                System.out.println("Enter Network Card: ");
                String networkCard = scanner.nextLine();
                builder.setNetworkCard(networkCard);
            }

            Computer customComputer = builder.build();
            System.out.println(customComputer);

            System.out.println("Do you want to create another computer? (yes/no): ");
            userChoice = scanner.nextLine();

        } while (userChoice.equalsIgnoreCase("yes"));

        System.out.println("Exiting the program.");
        scanner.close();
    }
}
