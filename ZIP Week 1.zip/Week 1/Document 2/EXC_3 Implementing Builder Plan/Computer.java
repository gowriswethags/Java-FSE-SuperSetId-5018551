public class Computer {
    // Required parameters
    private String CPU;
    private String RAM;
    private String storage;

    // Optional parameters
    private String GPU;
    private String soundCard;
    private String networkCard;

    // Private constructor to enforce object creation through Builder
    private Computer(ComputerBuilder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
        this.GPU = builder.GPU;
        this.soundCard = builder.soundCard;
        this.networkCard = builder.networkCard;
    }

    // Getters
    public String getCPU() {
        return CPU;
    }

    public String getRAM() {
        return RAM;
    }

    public String getStorage() {
        return storage;
    }

    public String getGPU() {
        return GPU;
    }

    public String getSoundCard() {
        return soundCard;
    }

    public String getNetworkCard() {
        return networkCard;
    }

    @Override
    public String toString() {
        return "Computer [CPU=" + CPU + ", RAM=" + RAM + ", storage=" + storage + 
               ", GPU=" + GPU + ", soundCard=" + soundCard + ", networkCard=" + networkCard + "]";
    }

    // Static nested Builder class
    public static class ComputerBuilder {
        // Required parameters
        private String CPU;
        private String RAM;
        private String storage;

        // Optional parameters
        private String GPU;
        private String soundCard;
        private String networkCard;

        // Constructor for required parameters
        public ComputerBuilder(String CPU, String RAM, String storage) {
            this.CPU = CPU;
            this.RAM = RAM;
            this.storage = storage;
        }

        // Methods for optional parameters
        public ComputerBuilder setGPU(String GPU) {
            this.GPU = GPU;
            return this;
        }

        public ComputerBuilder setSoundCard(String soundCard) {
            this.soundCard = soundCard;
            return this;
        }

        public ComputerBuilder setNetworkCard(String networkCard) {
            this.networkCard = networkCard;
            return this;
        }

        // Build method to create Computer instance
        public Computer build() {
            return new Computer(this);
        }
    }
}
