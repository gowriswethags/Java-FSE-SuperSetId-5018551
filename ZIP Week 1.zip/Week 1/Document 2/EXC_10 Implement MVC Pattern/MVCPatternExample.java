import java.util.ArrayList;
import java.util.List;
//import java.util.Optional;
import java.util.Scanner;

public class MVCPatternExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Student> students = new ArrayList<>();
        StudentView studentView = new StudentView();
        StudentController studentController = new StudentController(students, studentView);

        String userChoice;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Add student");
            System.out.println("2. Update student");
            System.out.println("3. Display all students");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            userChoice = scanner.nextLine();

            switch (userChoice) {
                case "1":
                    System.out.print("Enter student name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter student ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter student grade: ");
                    String grade = scanner.nextLine();
                    studentController.addStudent(new Student(name, id, grade));
                    System.out.println("Student added.");
                    break;

                case "2":
                    System.out.print("Enter student ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter new student name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new student grade: ");
                    String newGrade = scanner.nextLine();
                    studentController.updateStudent(updateId, newName, newGrade);
                    System.out.println("Student updated.");
                    break;

                case "3":
                    studentController.updateView();
                    break;

                case "4":
                    System.out.println("Exiting the program.");
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (!userChoice.equals("4"));

        scanner.close();
    }
}
