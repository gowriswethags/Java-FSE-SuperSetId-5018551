//VIEW

import java.util.List;

public class StudentView {
    public void displayStudentDetails(List<Student> students) {
        for (Student student : students) {
            System.out.println(student);
        }
    }
}

