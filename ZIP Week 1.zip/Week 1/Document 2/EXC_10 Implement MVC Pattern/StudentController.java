//CONTROLLERimport java.util.List;
import java.util.List;
import java.util.Optional;

public class StudentController {
    private List<Student> students;
    private StudentView studentView;

    public StudentController(List<Student> students, StudentView studentView) {
        this.students = students;
        this.studentView = studentView;
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public Optional<Student> findStudentById(int id) {
        return students.stream().filter(student -> student.getId() == id).findFirst();
    }

    public void updateStudent(int id, String name, String grade) {
        Optional<Student> studentOpt = findStudentById(id);
        if (studentOpt.isPresent()) {
            Student student = studentOpt.get();
            student.setName(name);
            student.setGrade(grade);
        } else {
            System.out.println("Student not found!");
        }
    }

    public void updateView() {
        studentView.displayStudentDetails(students);
    }
}
