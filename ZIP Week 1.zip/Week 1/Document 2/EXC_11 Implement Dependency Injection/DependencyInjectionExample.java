import java.util.Scanner;

public class DependencyInjectionExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Instantiate the concrete repository
        CustomerRepository customerRepository = new CustomerRepositoryImpl();
        
        // Inject the repository into the service
        CustomerService customerService = new CustomerService(customerRepository);

        String userChoice;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Add new customer");
            System.out.println("2. Find customer by ID");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            userChoice = scanner.nextLine();

            switch (userChoice) {
                case "1":
                    System.out.print("Enter customer ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter customer name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter customer email: ");
                    String email = scanner.nextLine();
                    customerService.addCustomer(new Customer(id, name, email));
                    System.out.println("Customer added.");
                    break;

                case "2":
                    System.out.print("Enter customer ID to find: ");
                    int searchId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    Customer customer = customerService.getCustomerById(searchId);
                    if (customer != null) {
                        System.out.println("Customer found: " + customer);
                    } else {
                        System.out.println("Customer not found.");
                    }
                    break;

                case "3":
                    System.out.println("Exiting the program.");
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (!userChoice.equals("3"));

        scanner.close();
    }
}
