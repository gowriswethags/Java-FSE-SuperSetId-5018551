# BookstoreAPI

This project is a RESTful API for managing an online bookstore. It includes the following dependencies:
- Spring Web
- Spring Boot DevTools
- Lombok