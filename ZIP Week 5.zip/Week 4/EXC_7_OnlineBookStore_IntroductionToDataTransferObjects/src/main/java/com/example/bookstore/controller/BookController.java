package com.example.bookstore.controller;

import com.example.bookstore.dto.BookDTO;
import com.example.bookstore.exception.BookNotFoundException;
import com.example.bookstore.mapper.BookMapper;
import com.example.bookstore.model.Book;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/books")
public class BookController {

    private List<Book> books = new ArrayList<>();
    private final BookMapper bookMapper = BookMapper.INSTANCE;

    @GetMapping
    public ResponseEntity<List<BookDTO>> getAllBooks(@RequestParam(required = false) String title,
                                                      @RequestParam(required = false) String author) {
        List<Book> filteredBooks;
        if (title != null && author != null) {
            filteredBooks = books.stream()
                    .filter(book -> book.getTitle().equalsIgnoreCase(title) && book.getAuthor().equalsIgnoreCase(author))
                    .collect(Collectors.toList());
        } else if (title != null) {
            filteredBooks = books.stream()
                    .filter(book -> book.getTitle().equalsIgnoreCase(title))
                    .collect(Collectors.toList());
        } else if (author != null) {
            filteredBooks = books.stream()
                    .filter(book -> book.getAuthor().equalsIgnoreCase(author))
                    .collect(Collectors.toList());
        } else {
            filteredBooks = books;
        }

        List<BookDTO> bookDTOs = filteredBooks.stream()
                .map(bookMapper::bookToBookDTO)
                .collect(Collectors.toList());

        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "Books-List");
        return new ResponseEntity<>(bookDTOs, headers, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BookDTO> getBookById(@PathVariable int id) {
        return books.stream()
                .filter(book -> book.getId() == id)
                .findFirst()
                .map(book -> {
                    BookDTO bookDTO = bookMapper.bookToBookDTO(book);
                    HttpHeaders headers = new HttpHeaders();
                    headers.add("Custom-Header", "Book-Detail");
                    return new ResponseEntity<>(bookDTO, headers, HttpStatus.OK);
                })
                .orElseThrow(() -> new BookNotFoundException("Book with ID " + id + " not found"));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<BookDTO> addBook(@RequestBody BookDTO bookDTO) {
        Book book = bookMapper.bookDTOToBook(bookDTO);
        books.add(book);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Location", "/books/" + book.getId());
        return new ResponseEntity<>(bookDTO, headers, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<BookDTO> updateBook(@PathVariable int id, @RequestBody BookDTO bookDTO) {
        Optional<Book> existingBook = books.stream().filter(b -> b.getId() == id).findFirst();
        if (existingBook.isPresent()) {
            books.remove(existingBook.get());
            Book book = bookMapper.bookDTOToBook(bookDTO);
            book.setId(id);
            books.add(book);
            HttpHeaders headers = new HttpHeaders();
            headers.add("Custom-Header", "Book-Updated");
            return new ResponseEntity<>(bookDTO, headers, HttpStatus.OK);
        } else {
            throw new BookNotFoundException("Book with ID " + id + " not found");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable int id) {
        boolean removed = books.removeIf(book -> book.getId() == id);
        if (removed) {
            HttpHeaders headers = new HttpHeaders();
            headers.add("Custom-Header", "Book-Deleted");
            return new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
        } else {
            throw new BookNotFoundException("Book with ID " + id + " not found");
        }
    }
}
