package com.bookstore;

@SpringBootApplication
public class OnlineBookstoreApplication {
    private static Object SpringApplication;

    public static void main(String[] args) {
        ((Object) SpringApplication).run(OnlineBookstoreApplication.class, args);
    }
}
