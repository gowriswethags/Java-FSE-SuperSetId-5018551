package com.bookstore.repository;

public @interface Repository {

}
