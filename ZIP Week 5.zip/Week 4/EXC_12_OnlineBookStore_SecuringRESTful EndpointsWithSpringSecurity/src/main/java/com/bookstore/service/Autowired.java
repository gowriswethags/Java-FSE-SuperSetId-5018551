package com.bookstore.service;

public @interface Autowired {

}
