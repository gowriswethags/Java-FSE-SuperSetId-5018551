package com.bookstore.model;

public class GenerationType {

    public static final String IDENTITY = null;

}
