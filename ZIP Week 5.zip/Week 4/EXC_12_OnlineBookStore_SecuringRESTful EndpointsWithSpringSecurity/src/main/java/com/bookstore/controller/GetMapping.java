package com.bookstore.controller;

public @interface GetMapping {

    String value();

}
