package com.bookstore.config;

public class WebSecurityConfigurerAdapter {

}
