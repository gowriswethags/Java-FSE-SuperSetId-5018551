package com.bookstore.model;

public @interface Id {

}
