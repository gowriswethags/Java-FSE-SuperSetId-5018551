package com.bookstore.security;

public interface UserDetailsService {

    UserDetails loadUserByUsername(String username);

}
