package com.bookstore.util;

public class SignatureAlgorithm {

    public static final String HS512 = null;

}
