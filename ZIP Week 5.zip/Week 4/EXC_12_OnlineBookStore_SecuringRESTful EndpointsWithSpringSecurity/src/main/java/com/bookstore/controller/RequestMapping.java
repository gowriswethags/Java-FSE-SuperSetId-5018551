package com.bookstore.controller;

public @interface RequestMapping {

    String value();

}
