package com.bookstore;

public @interface SpringBootApplication {

}
