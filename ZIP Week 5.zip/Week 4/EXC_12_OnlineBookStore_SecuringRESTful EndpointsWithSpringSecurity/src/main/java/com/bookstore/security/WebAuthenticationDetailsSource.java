package com.bookstore.security;

public class WebAuthenticationDetailsSource {

    public Object buildDetails(HttpServletRequest request) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'buildDetails'");
    }

}
