package com.bookstore.util;

public class Claims {

}
