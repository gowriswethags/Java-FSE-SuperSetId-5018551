package com.bookstore.service;

public @interface Service {

}
