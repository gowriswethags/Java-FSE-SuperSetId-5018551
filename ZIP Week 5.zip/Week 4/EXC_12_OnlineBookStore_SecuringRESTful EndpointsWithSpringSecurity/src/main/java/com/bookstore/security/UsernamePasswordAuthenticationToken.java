package com.bookstore.security;

public class UsernamePasswordAuthenticationToken {

    public void setDetails(Object details) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setDetails'");
    }

}
