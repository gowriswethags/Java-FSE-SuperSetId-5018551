package com.bookstore.security;

public interface AuthenticationEntryPoint {

}
