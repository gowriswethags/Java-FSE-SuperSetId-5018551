package com.bookstore.security;

import com.bookstore.model.User;
import com.bookstore.repository.UserRepository;
import com.bookstore.service.Autowired;
import com.bookstore.service.Service;
import com.bookstore.util.UserDetails;

import java.util.ArrayList;

@Service
public class JwtUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public org.springframework.security.core.userdetails.User loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException();
        }
        return new org.springframework.security.core.userdetails.User();
    }
}
