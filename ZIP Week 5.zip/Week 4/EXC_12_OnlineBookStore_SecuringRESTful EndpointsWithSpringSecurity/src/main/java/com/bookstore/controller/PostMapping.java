package com.bookstore.controller;

public @interface PostMapping {

}
