package com.bookstore.config;

public class SessionCreationPolicy {

    public static final String STATELESS = null;

}
