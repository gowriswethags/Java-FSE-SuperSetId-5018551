package com.bookstore.security;

public class HttpServletRequest {

    public String getHeader(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getHeader'");
    }

}
