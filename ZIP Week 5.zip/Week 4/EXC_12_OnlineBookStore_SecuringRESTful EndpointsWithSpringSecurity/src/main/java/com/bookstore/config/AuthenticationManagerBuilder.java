package com.bookstore.config;

import com.bookstore.security.JwtUserDetailsService;

public class AuthenticationManagerBuilder {

    public Object userDetailsService(JwtUserDetailsService jwtUserDetailsService) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'userDetailsService'");
    }

}
