package com.bookstore.security;

public class HttpServletResponse {

    public static final String SC_UNAUTHORIZED = null;

    public void sendError(String scUnauthorized, String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'sendError'");
    }

}
