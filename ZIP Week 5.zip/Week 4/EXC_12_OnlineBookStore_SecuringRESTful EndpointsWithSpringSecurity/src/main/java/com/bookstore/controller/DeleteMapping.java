package com.bookstore.controller;

public @interface DeleteMapping {

    String value();

}
