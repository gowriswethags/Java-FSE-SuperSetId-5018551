package com.bookstore.controller;

public class ResponseEntity<T> {

    public static Object ok() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'ok'");
    }

    public static Object notFound() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'notFound'");
    }

}
