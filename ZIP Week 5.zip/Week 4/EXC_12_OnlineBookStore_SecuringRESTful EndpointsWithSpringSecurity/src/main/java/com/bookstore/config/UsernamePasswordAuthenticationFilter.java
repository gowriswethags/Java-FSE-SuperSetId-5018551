package com.bookstore.config;

public class UsernamePasswordAuthenticationFilter {

}
