package com.bookstore.config;

public @interface EnableWebSecurity {

}
