package com.bookstore.util;

public @interface Component {

}
