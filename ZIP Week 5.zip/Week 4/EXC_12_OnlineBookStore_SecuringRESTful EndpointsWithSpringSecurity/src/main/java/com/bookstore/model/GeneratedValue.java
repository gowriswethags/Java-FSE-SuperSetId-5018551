package com.bookstore.model;

public @interface GeneratedValue {

    String strategy();

}
