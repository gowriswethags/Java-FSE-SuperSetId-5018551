package com.bookstore.security;

public class SecurityContextHolder {

    public static Object getContext() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getContext'");
    }

}
