package com.example.bookstore;

import org.apache.tomcat.util.http.parser.MediaType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.example.bookstore.model.Book;

@WebMvcTest
public class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testGetBookJson() throws Exception {
        mockMvc.perform(get("/api/books/1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(((Object) status()).isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.title").value("1984"));
    }

    private Object status() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'status'");
    }

    private Object get(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'get'");
    }

    @Test
    public void testGetBookXml() throws Exception {
        mockMvc.perform(get("/api/books/1")
                .accept(MediaType.APPLICATION_XML))
                .andExpect(((Object) status()).isOk())
                .andExpect(MockMvcResultMatchers.xpath("/Book/title").string("1984"));
    }
}
