package com.example.bookstore.model;

public @interface XmlRootElement {

}
