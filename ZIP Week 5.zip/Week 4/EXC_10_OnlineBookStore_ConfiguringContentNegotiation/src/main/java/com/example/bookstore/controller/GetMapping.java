package com.example.bookstore.controller;

public @interface GetMapping {

    String produces();

    String value();

}
