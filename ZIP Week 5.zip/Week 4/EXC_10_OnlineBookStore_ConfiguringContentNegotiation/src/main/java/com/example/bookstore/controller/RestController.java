package com.example.bookstore.controller;

public @interface RestController {

}
