package com.example.bookstore.controller;

import com.example.bookstore.model.Book;
import java.util.HashMap;
import java.util.Map;

import org.apache.tomcat.util.http.parser.MediaType;

@RestController
@RequestMapping("/api/books")
public class BookController {

    private static final Map<Long, Book> books = new HashMap<>();

    static {
        books.put(1L, new Book(1L, "1984", "George Orwell"));
        books.put(2L, new Book(2L, "To Kill a Mockingbird", "Harper Lee"));
    }

    @GetMapping(value = "/{id}", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public Book getBook(@PathVariable Long id) {
        return books.get(id);
    }
}
