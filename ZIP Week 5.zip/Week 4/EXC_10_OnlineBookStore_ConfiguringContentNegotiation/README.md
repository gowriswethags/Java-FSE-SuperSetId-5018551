# Online Bookstore

## Overview

This project is a basic implementation of a RESTful API for managing books and customers in an online bookstore.

## Project Structure

- `OnlineBookstoreApplication.java`: Main entry point of the application.
- `BookController.java`: Contains RESTful endpoints for managing books.
- `CustomerController.java`: Contains RESTful endpoints for customer registrations.
- `Book.java`: Represents the Book entity.
- `Customer.java`: Represents the Customer entity.
- `GlobalExceptionHandler.java`: Handles exceptions globally and customizes responses.

## Endpoints

### Books

- `GET /books`: Retrieve all books. Optional query parameters:
  - `title`: Filter by book title.
  - `author`: Filter by book author.
  - **Response Headers**:
    - `Custom-Header`: Provides additional information.
- `GET /books/{id}`: Retrieve a book by ID.
  - **Response Headers**:
    - `Custom-Header`: Provides additional information.
  - **Errors**:
    - `404 Not Found`: If the book is not found.
- `POST /books`: Add a new book.
  - **Response Status**:
    - `201 Created` with `Location` header indicating the resource location.
- `PUT /books/{id}`: Update an existing book.
  - **Response Headers**:
    - `Custom-Header`: Indicates that the book was updated.
  - **Errors**:
    - `404 Not Found`: If the book is not found.
- `DELETE /books/{id}`: Delete a book by ID.
  - **Response Headers**:
    - `Custom-Header`: Indicates that the book was deleted.
  - **Response Status**:
    - `204 No Content` if the book was successfully deleted.
    - `404 Not Found` if the book was not found.

### Customers

- `POST /customers`: Create a new customer by sending a JSON request body.
- `POST /customers/register`: Register a customer by sending form data with `name`, `email`, and `phone`.
