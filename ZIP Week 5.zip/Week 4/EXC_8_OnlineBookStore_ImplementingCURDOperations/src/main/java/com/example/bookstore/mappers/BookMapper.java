package com.example.bookstore.mappers;

import com.example.bookstore.dto.BookDTO;
import com.example.bookstore.model.Book;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface BookMapper {

    BookMapper INSTANCE = Mappers.getMapper(BookMapper.class);

    BookDTO bookToBookDTO(Book book);

    Book bookDTOToBook(BookDTO bookDTO);

    List<BookDTO> booksToBookDTOs(List<Book> books);

    List<Book> bookDTOsToBooks(List<BookDTO> bookDTOs);
}
