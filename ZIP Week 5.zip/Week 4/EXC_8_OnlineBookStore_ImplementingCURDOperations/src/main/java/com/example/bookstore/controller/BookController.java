package com.example.bookstore.controller;

import com.example.bookstore.dto.BookDTO;
import com.example.bookstore.exception.ResourceNotFoundException;
import com.example.bookstore.mappers.BookMapper;
import com.example.bookstore.model.Book;
import com.example.bookstore.repository.BookRepository;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private BookMapper bookMapper;

    @GetMapping
    public List<BookDTO> getAllBooks() {
        List<Book> books = bookRepository.findAll();
        return bookMapper.booksToBookDTOs(books);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BookDTO> getBookById(@PathVariable @Min(1) int id) {
        Optional<Book> book = bookRepository.findById(id);
        if (!book.isPresent()) {
            throw new ResourceNotFoundException("Book with ID " + id + " not found");
        }
        BookDTO bookDTO = bookMapper.bookToBookDTO(book.get());
        return new ResponseEntity<>(bookDTO, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<BookDTO> createBook(@Valid @RequestBody BookDTO bookDTO) {
        Book book = bookMapper.bookDTOToBook(bookDTO);
        book = bookRepository.save(book);
        BookDTO createdBookDTO = bookMapper.bookToBookDTO(book);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "Book-Created");
        return new ResponseEntity<>(createdBookDTO, headers, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<BookDTO> updateBook(@PathVariable @Min(1) int id, @Valid @RequestBody BookDTO bookDTO) {
        if (!bookRepository.existsById(id)) {
            throw new ResourceNotFoundException("Book with ID " + id + " not found");
        }
        Book book = bookMapper.bookDTOToBook(bookDTO);
        book.setId(id);
        book = bookRepository.save(book);
        BookDTO updatedBookDTO = bookMapper.bookToBookDTO(book);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "Book-Updated");
        return new ResponseEntity<>(updatedBookDTO, headers, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable @Min(1) int id) {
        if (!bookRepository.existsById(id)) {
            throw new ResourceNotFoundException("Book with ID " + id + " not found");
        }
        bookRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
