package com.example.bookstore.mappers;

import com.example.bookstore.dto.CustomerDTO;
import com.example.bookstore.model.Customer;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface CustomerMapper {

    CustomerMapper INSTANCE = Mappers.getMapper(CustomerMapper.class);

    CustomerDTO customerToCustomerDTO(Customer customer);

    Customer customerDTOToCustomer(CustomerDTO customerDTO);

    List<CustomerDTO> customersToCustomerDTOs(List<Customer> customers);

    List<Customer> customerDTOsToCustomers(List<CustomerDTO> customerDTOs);
}
