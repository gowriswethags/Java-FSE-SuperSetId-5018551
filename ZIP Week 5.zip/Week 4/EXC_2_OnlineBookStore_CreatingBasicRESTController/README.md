# Online Bookstore

## Overview

This project is a basic implementation of a RESTful API for managing books in an online bookstore.

## Project Structure

- `OnlineBookstoreApplication.java`: Main entry point of the application.
- `BookController.java`: Contains RESTful endpoints for managing books.
- `Book.java`: Represents the Book entity.

## Endpoints

- `GET /books`: Retrieve all books.
- `POST /books`: Add a new book.
- `PUT /books/{id}`: Update an existing book.
- `DELETE /books/{id}`: Delete a book by ID.
