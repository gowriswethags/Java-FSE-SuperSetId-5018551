package com.example.bookstore;

import com.example.bookstore.service.BookService;
import io.micrometer.core.instrument.MeterRegistry;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.mockito.Mockito.verify;

@SpringBootTest
public class BookServiceTests {

    @Autowired
    private BookService bookService;

    @Autowired
    private MeterRegistry meterRegistry;

    @Test
    public void testHandleBookRequest() {
        // Create a mock for CustomMetrics
        CustomMetrics customMetrics = Mockito.mock(CustomMetrics.class);

        // Inject the mock into BookService
        bookService = new BookService(customMetrics);

        // Call the method to be tested
        bookService.handleBookRequest();

        // Verify that the custom metrics method was called
        verify(customMetrics).incrementBookRequest();
    }
}
