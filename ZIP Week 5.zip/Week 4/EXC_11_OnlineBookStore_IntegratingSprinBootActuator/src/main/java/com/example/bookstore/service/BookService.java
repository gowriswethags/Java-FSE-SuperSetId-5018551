package com.example.bookstore.service;

import com.example.bookstore.metrics.CustomMetrics;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    private final CustomMetrics customMetrics;

    @Autowired
    public BookService(CustomMetrics customMetrics) {
        this.customMetrics = customMetrics;
    }

    public void handleBookRequest() {
        // Your business logic here
        customMetrics.incrementBookRequest();
    }
}
