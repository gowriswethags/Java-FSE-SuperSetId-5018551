package com.example.bookstore.metrics;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Counter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CustomMetrics {

    private final Counter bookRequestCounter;

    @Autowired
    public CustomMetrics(MeterRegistry meterRegistry) {
        this.bookRequestCounter = meterRegistry.counter("book_requests_total");
    }

    public void incrementBookRequest() {
        bookRequestCounter.increment();
    }

    public Counter getBookRequestCounter() {
        return bookRequestCounter;
    }
}
