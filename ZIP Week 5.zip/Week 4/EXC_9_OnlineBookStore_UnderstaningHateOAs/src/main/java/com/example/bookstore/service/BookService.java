package com.example.bookstore.service;

import com.example.bookstore.model.Book;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    // Replace with actual repository access
    public Book getBookById(Long id) {
        // Mock implementation
        return new Book(); 
    }

    public List<Book> getAllBooks() {
        // Mock implementation
        return List.of(new Book());
    }
}
