package com.example.bookstore.service;

import com.example.bookstore.model.Customer;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    // Replace with actual repository access
    public Customer getCustomerById(Long id) {
        // Mock implementation
        return new Customer(); 
    }

    public List<Customer> getAllCustomers() {
        // Mock implementation
        return List.of(new Customer());
    }
}
