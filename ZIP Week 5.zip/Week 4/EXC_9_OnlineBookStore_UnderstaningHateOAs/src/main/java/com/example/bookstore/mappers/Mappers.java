package com.example.bookstore.mappers;

public class Mappers {

    static CustomerMapper getMapper(Class<BookMapper> class1) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getMapper'");
    }

}
