package com.example.bookstore.controller;

import com.example.bookstore.assembler.CustomerResourceAssembler;
import com.example.bookstore.model.Customer;
import com.example.bookstore.service.CustomerService;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private final CustomerService customerService;
    private final CustomerResourceAssembler assembler;

    public CustomerController(CustomerService customerService, CustomerResourceAssembler assembler) {
        this.customerService = customerService;
        this.assembler = assembler;
    }

    @GetMapping("/{id}")
    public EntityModel<Customer> getCustomerById(@PathVariable Long id) {
        Customer customer = customerService.getCustomerById(id);
        return assembler.toModel(customer);
    }

    @GetMapping
    public CollectionModel<EntityModel<Customer>> getAllCustomers() {
        List<Customer> customers = customerService.getAllCustomers();
        List<EntityModel<Customer>> customerModels = customers.stream()
                .map(assembler::toModel)
                .toList();
        return CollectionModel.of(customerModels);
    }
}
