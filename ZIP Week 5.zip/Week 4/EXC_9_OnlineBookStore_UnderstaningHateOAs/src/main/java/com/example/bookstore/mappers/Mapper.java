package com.example.bookstore.mappers;

public @interface Mapper {

}
