package com.example.bookstore.controller;

import com.example.bookstore.assembler.BookResourceAssembler;
import com.example.bookstore.model.Book;
import com.example.bookstore.service.BookService;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    private final BookService bookService;
    private final BookResourceAssembler assembler;

    public BookController(BookService bookService, BookResourceAssembler assembler) {
        this.bookService = bookService;
        this.assembler = assembler;
    }

    @GetMapping("/{id}")
    public EntityModel<Book> getBookById(@PathVariable Long id) {
        Book book = bookService.getBookById(id);
        return assembler.toModel(book);
    }

    @GetMapping
    public CollectionModel<EntityModel<Book>> getAllBooks() {
        List<Book> books = bookService.getAllBooks();
        List<EntityModel<Book>> bookModels = books.stream()
                .map(assembler::toModel)
                .toList();
        return CollectionModel.of(bookModels);
    }
}
