package com.employeesystem;

import com.employeesystem.entity.Department;
import com.employeesystem.entity.Employee;
import com.employeesystem.repository.DepartmentRepository;
import com.employeesystem.repository.EmployeeRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

@SpringBootTest
class EmployeeManagementSystemApplicationTests {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Test
    void contextLoads() {
        // Test the application context loads successfully
    }

    @Test
    void testFindByDepartmentName() {
        Department department = new Department();
        department.setName("Marketing");
        departmentRepository.save(department);

        Employee employee = new Employee();
        employee.setName("Alice");
        employee.setEmail("alice@example.com");
        employee.setDepartment(department);
        employeeRepository.save(employee);

        List<Employee> employees = employeeRepository.findByDepartmentName("Marketing");
        assertThat(employees).hasSize(1);
        assertThat(employees.get(0).getName()).isEqualTo("Alice");
    }

    @Test
    void testFindByEmail() {
        Employee employee = new Employee();
        employee.setName("Bob");
        employee.setEmail("bob@example.com");
        employeeRepository.save(employee);

        Employee foundEmployee = employeeRepository.findByEmail("bob@example.com");
        assertThat(foundEmployee).isNotNull();
        assertThat(foundEmployee.getName()).isEqualTo("Bob");
    }
}
