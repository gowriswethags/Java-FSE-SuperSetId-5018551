INSERT INTO department (id, name) VALUES (1, 'HR');
INSERT INTO department (id, name) VALUES (2, 'IT');

INSERT INTO employee (id, name, email, department_id) VALUES (1, 'John Doe', 'john.doe@example.com', 1);
INSERT INTO employee (id, name, email, department_id) VALUES (2, 'Jane Smith', 'jane.smith@example.com', 2);
