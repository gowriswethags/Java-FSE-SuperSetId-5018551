package com.example.employeemanagement.config;

public @interface Autowired {

}
