package com.example.employeemanagement.model;

import javax.annotation.processing.Generated;

@Entity
@Table(name = "employees")
@BatchSize(size = 30)
public class Employee {

    @Id
    @GeneratedValue(strategy = Generated.IDENTITY)
    private Long id;
    
    private String name;
    private String department;

    // Getters and Setters
}
