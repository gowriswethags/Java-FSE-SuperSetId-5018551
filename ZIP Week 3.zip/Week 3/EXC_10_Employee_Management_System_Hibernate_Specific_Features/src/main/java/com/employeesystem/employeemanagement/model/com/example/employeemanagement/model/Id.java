package com.example.employeemanagement.model;

public @interface Id {

}
