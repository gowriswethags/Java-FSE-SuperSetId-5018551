package com.example.employeemanagement.model;

import javax.annotation.processing.Generated;

@Entity
@Table(name = "departments")
@BatchSize(size = 30)
public class Department {

    @Id
    @GeneratedValue(strategy = Generated.IDENTITY)
    private Long id;

    private String name;

    // Getters and Setters
}
