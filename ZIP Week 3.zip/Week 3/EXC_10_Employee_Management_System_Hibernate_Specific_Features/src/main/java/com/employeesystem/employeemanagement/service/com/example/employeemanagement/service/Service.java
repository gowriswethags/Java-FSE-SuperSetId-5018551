package com.example.employeemanagement.service;

public @interface Service {

}
