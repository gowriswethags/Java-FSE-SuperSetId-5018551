package com.example.employeemanagement.config;

public @interface Configuration {

}
