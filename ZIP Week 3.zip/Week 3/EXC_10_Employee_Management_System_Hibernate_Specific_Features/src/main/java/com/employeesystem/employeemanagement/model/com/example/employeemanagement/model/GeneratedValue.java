package com.example.employeemanagement.model;

public @interface GeneratedValue {

    String strategy();

}
