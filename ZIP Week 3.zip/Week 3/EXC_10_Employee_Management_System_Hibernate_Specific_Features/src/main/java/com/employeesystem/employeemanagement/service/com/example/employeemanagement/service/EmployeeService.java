package com.example.employeemanagement.service;

import com.example.employeemanagement.config.Autowired;
import com.example.employeemanagement.model.Employee;
import java.util.List;

@Service
public class EmployeeService<EmployeeRepository> {

    @Autowired
    private EmployeeRepository employeeRepository;

    @SuppressWarnings("unchecked")
    @Transactional
    public void batchInsertEmployees(List<Employee> employees) {
        final int batchSize = 30;
        for (int i = 0; i < employees.size(); i++) {
            ((Object) employeeRepository).save(employees.get(i));
            if (i > 0 && i % batchSize == 0) {
                // Flush and clear the session to manage memory usage
                ((Object) employeeRepository).flush();
                ((List<Employee>) employeeRepository).clear();
            }
        }
    }
}
