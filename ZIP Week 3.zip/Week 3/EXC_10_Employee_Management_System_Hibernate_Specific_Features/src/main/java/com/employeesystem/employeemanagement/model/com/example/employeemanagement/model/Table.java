package com.example.employeemanagement.model;

public @interface Table {

    String name();

}
