
public @interface Transactional {

}
