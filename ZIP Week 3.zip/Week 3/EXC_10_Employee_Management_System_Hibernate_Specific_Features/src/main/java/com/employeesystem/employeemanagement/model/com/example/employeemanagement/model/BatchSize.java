package com.example.employeemanagement.model;

public @interface BatchSize {

    int size();

}
