
public @interface Autowired {

}
