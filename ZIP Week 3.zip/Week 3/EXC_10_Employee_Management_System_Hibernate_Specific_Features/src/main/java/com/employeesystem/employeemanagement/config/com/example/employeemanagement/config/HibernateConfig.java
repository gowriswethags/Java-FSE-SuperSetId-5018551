package com.example.employeemanagement.config;

import java.util.Properties;

import javax.sql.DataSource;

@Configuration
public class HibernateConfig<Environment, LocalSessionFactoryBean> {

    @Autowired
    private DataSource dataSource;

    @Autowired
    private Environment env;

    @Bean
    public LocalSessionFactoryBean sessionFactory() {
        LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
        ((Object) sessionFactory).setDataSource(dataSource);
        ((Object) sessionFactory).setPackagesToScan(new String[] { "com.example.employeemanagement.model" });
        ((Object) sessionFactory).setHibernateProperties(hibernateProperties());
        return sessionFactory;
    }

    private Properties hibernateProperties() {
        Properties properties = new Properties();
        properties.put("hibernate.dialect", ((Properties) env).getProperty("spring.jpa.properties.hibernate.dialect"));
        properties.put("hibernate.hbm2ddl.auto", ((Properties) env).getProperty("spring.jpa.hibernate.ddl-auto"));
        properties.put("hibernate.show_sql", ((Properties) env).getProperty("spring.jpa.show-sql"));
        properties.put("hibernate.jdbc.batch_size", ((Properties) env).getProperty("spring.jpa.properties.hibernate.jdbc.batch_size"));
        properties.put("hibernate.order_inserts", ((Properties) env).getProperty("spring.jpa.properties.hibernate.order_inserts"));
        properties.put("hibernate.order_updates", ((Properties) env).getProperty("spring.jpa.properties.hibernate.order_updates"));
        return properties;
    }
}
