package com.employeesystem;

public @interface Test {

}
