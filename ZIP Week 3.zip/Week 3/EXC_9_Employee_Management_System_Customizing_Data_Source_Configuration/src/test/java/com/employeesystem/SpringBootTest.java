package com.employeesystem;

public @interface SpringBootTest {

}
