package com.employeesystem;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

@SpringBootTest
public class DataSourceTest {

    @Autowired
    @Qualifier("primaryDataSource")
    private DataSource primaryDataSource;

    @Autowired
    @Qualifier("secondaryDataSource")
    private DataSource secondaryDataSource;

    @Test
    public void testPrimaryDataSource() {
        assertNotNull(primaryDataSource);
    }

    private void assertNotNull(DataSource primaryDataSource2) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'assertNotNull'");
    }

    @Test
    public void testSecondaryDataSource() {
        assertNotNull(secondaryDataSource);
    }
}
