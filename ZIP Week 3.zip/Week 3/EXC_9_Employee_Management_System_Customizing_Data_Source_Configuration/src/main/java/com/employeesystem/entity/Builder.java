package com.employeesystem.entity;

public @interface Builder {

}
