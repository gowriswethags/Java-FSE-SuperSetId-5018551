package com.employeesystem.service;

import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
    // Business logic for employee management
}
