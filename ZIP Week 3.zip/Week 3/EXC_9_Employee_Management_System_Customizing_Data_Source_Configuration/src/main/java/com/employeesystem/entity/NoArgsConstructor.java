package com.employeesystem.entity;

public @interface NoArgsConstructor {

}
