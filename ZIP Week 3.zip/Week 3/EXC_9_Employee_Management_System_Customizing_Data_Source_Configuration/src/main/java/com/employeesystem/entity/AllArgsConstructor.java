package com.employeesystem.entity;

public @interface AllArgsConstructor {

}
