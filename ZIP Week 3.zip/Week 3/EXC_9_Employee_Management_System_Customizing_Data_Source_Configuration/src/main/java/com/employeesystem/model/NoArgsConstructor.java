package com.employeesystem.model;

public @interface NoArgsConstructor {

}
