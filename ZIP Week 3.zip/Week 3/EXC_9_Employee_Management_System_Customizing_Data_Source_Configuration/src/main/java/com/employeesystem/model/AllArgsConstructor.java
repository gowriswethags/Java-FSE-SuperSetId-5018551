package com.employeesystem.model;

public @interface AllArgsConstructor {

}
