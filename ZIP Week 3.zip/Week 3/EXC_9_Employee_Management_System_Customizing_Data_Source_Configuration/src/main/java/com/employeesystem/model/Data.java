package com.employeesystem.model;

public @interface Data {

}
