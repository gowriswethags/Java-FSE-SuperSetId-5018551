package com.employeesystem.model;

public @interface Builder {

}
