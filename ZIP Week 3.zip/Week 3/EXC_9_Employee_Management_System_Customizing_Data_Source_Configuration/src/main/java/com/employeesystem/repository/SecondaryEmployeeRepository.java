package com.employeesystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employeesystem.service.EmployeeService;

@Repository
public interface SecondaryEmployeeRepository extends JpaRepository<EmployeeService, Long> {
    // Custom queries for secondary data source
}
