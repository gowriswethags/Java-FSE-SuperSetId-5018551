package com.employeesystem.entity;

public @interface Data {

}
