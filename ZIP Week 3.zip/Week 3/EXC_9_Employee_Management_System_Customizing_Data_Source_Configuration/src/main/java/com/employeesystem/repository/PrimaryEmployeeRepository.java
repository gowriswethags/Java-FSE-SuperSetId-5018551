package com.employeesystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employeesystem.service.EmployeeService;

@Repository
public interface PrimaryEmployeeRepository extends JpaRepository<EmployeeService, Long> {
    // Custom queries for primary data source
}
