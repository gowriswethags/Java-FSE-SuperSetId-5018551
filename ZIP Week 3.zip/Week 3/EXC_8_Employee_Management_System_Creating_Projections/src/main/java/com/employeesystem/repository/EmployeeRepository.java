package com.employeesystem.repository;

import com.employeesystem.dto.EmployeeDepartmentDTO;
import com.employeesystem.dto.EmployeeNameOnly;
import com.employeesystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<EmployeeNameOnly> findBy();

    @Query("SELECT new com.employeesystem.dto.EmployeeDepartmentDTO(e.name, e.department.name) FROM Employee e")
    List<EmployeeDepartmentDTO> findEmployeeDepartmentDetails();
}
