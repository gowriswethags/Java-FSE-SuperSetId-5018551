package com.employeesystem.projection;

public interface EmployeeProjection {
    Long getId();
    String getName();
    String getEmail();
    String getDepartmentName();
}
