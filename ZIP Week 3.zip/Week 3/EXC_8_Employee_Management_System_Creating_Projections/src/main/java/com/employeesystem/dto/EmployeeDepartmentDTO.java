package com.employeesystem.dto;

import org.springframework.beans.factory.annotation.Value;

public class EmployeeDepartmentDTO {
    private String employeeName;
    private String departmentName;

    public EmployeeDepartmentDTO(String employeeName, String departmentName) {
        this.employeeName = employeeName;
        this.departmentName = departmentName;
    }

    @Value("#{target.name}")
    public String getEmployeeName() {
        return employeeName;
    }

    @Value("#{target.department.name}")
    public String getDepartmentName() {
        return departmentName;
    }
}
