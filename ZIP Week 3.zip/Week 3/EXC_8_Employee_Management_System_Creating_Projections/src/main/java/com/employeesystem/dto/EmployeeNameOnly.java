package com.employeesystem.dto;

public interface EmployeeNameOnly {
    String getName();
}
