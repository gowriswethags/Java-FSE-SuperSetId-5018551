package com.employeesystem.projection;

public interface DepartmentProjection {
    Long getId();
    String getName();
}
