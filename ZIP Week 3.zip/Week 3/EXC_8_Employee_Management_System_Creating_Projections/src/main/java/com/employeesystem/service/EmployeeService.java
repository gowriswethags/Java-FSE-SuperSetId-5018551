package com.employeesystem.service;

import com.employeesystem.dto.EmployeeDepartmentDTO;
import com.employeesystem.dto.EmployeeNameOnly;
import com.employeesystem.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public List<EmployeeNameOnly> getEmployeeNames() {
        return employeeRepository.findBy();
    }

    public List<EmployeeDepartmentDTO> getEmployeeDepartmentDetails() {
        return employeeRepository.findEmployeeDepartmentDetails();
    }
}
