package com.employeesystem.controller;

import com.employeesystem.dto.EmployeeDepartmentDTO;
import com.employeesystem.dto.EmployeeNameOnly;
import com.employeesystem.service.EmployeeService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping("/employees/names")
    public List<EmployeeNameOnly> getEmployeeNames() {
        return employeeService.getEmployeeNames();
    }

    @GetMapping("/employees/departments")
    public List<EmployeeDepartmentDTO> getEmployeeDepartmentDetails() {
        return employeeService.getEmployeeDepartmentDetails();
    }
}
