package com.employeesystem;

import com.employeesystem.entity.Employee;
import com.employeesystem.repository.EmployeeRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class EmployeeManagementSystemApplicationTests {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Test
    void testPaginationAndSorting() {
        Page<Employee> page = employeeRepository.findAll(PageRequest.of(0, 2, Sort.by("name")));
        assertThat(page.getContent()).hasSize(2);
        assertThat(page.getTotalElements()).isGreaterThan(2);
        assertThat(page.getContent().get(0).getName()).isLessThanOrEqualTo(page.getContent().get(1).getName());
    }
}
