INSERT INTO department (name) VALUES ('HR');
INSERT INTO department (name) VALUES ('IT');

INSERT INTO employee (first_name, last_name, email, department_id) VALUES ('John', 'Doe', 'john.doe@example.com', 1);
INSERT INTO employee (first_name, last_name, email, department_id) VALUES ('Jane', 'Smith', 'jane.smith@example.com', 2);
