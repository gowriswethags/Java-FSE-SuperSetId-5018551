package com.employeesystem.config;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class AuditorAwareImpl implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        // For demonstration, using a static username. In a real application, retrieve the current user from security context.
        return Optional.of("Admin");
    }
}
