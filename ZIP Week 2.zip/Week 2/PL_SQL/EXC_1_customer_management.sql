-- Scenario 1: Apply a Discount to Loan Interest Rates for Customers Above 60 Years Old

DECLARE
    CURSOR c_customers IS
        SELECT customer_id, age, loan_interest_rate
        FROM customers
        WHERE age > 60;
    
    v_customer_id customers.customer_id%TYPE;
    v_age customers.age%TYPE;
    v_loan_interest_rate customers.loan_interest_rate%TYPE;
BEGIN
    OPEN c_customers;
    LOOP
        FETCH c_customers INTO v_customer_id, v_age, v_loan_interest_rate;
        EXIT WHEN c_customers%NOTFOUND;
        
        -- Apply 1% discount to the current loan interest rate
        UPDATE customers
        SET loan_interest_rate = loan_interest_rate - 1
        WHERE customer_id = v_customer_id;
    END LOOP;
    CLOSE c_customers;
    
    DBMS_OUTPUT.PUT_LINE('Interest rates updated for customers above 60.');
END;
/

-- Scenario 2: Promote Customers to VIP Status Based on Their Balance

DECLARE
    CURSOR c_customers IS
        SELECT customer_id, balance
        FROM customers
        WHERE balance > 10000;
    
    v_customer_id customers.customer_id%TYPE;
    v_balance customers.balance%TYPE;
BEGIN
    OPEN c_customers;
    LOOP
        FETCH c_customers INTO v_customer_id, v_balance;
        EXIT WHEN c_customers%NOTFOUND;
        
        -- Set IsVIP flag to TRUE
        UPDATE customers
        SET IsVIP = TRUE
        WHERE customer_id = v_customer_id;
    END LOOP;
    CLOSE c_customers;
    
    DBMS_OUTPUT.PUT_LINE('VIP status updated for eligible customers.');
END;
/

-- Scenario 3: Send Reminders to Customers Whose Loans Are Due Within the Next 30 Days

DECLARE
    CURSOR c_loans IS
        SELECT loan_id, customer_id, due_date
        FROM loans
        WHERE due_date BETWEEN SYSDATE AND SYSDATE + 30;
    
    v_loan_id loans.loan_id%TYPE;
    v_customer_id loans.customer_id%TYPE;
    v_due_date loans.due_date%TYPE;
    v_customer_name customers.name%TYPE;
BEGIN
    OPEN c_loans;
    LOOP
        FETCH c_loans INTO v_loan_id, v_customer_id, v_due_date;
        EXIT WHEN c_loans%NOTFOUND;
        
        -- Fetch customer name for the reminder message
        SELECT name INTO v_customer_name
        FROM customers
        WHERE customer_id = v_customer_id;
        
        -- Print reminder message
        DBMS_OUTPUT.PUT_LINE('Reminder: Dear ' || v_customer_name || ', your loan (ID: ' || v_loan_id || ') is due on ' || TO_CHAR(v_due_date, 'DD-MON-YYYY') || '.');
    END LOOP;
    CLOSE c_loans;
    
    DBMS_OUTPUT.PUT_LINE('Reminders sent for loans due in the next 30 days.');
END;
/
