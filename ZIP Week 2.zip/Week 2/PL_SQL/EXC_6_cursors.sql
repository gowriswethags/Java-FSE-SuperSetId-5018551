-- Scenario 1: Generate Monthly Statements for All Customers

DECLARE
    CURSOR cur_transactions IS
        SELECT customer_id, transaction_id, transaction_date, transaction_amount, transaction_type
        FROM transactions
        WHERE transaction_date BETWEEN TRUNC(SYSDATE, 'MM') AND LAST_DAY(SYSDATE);
        
    v_customer_id transactions.customer_id%TYPE;
    v_transaction_id transactions.transaction_id%TYPE;
    v_transaction_date transactions.transaction_date%TYPE;
    v_transaction_amount transactions.transaction_amount%TYPE;
    v_transaction_type transactions.transaction_type%TYPE;
    
BEGIN
    OPEN cur_transactions;
    LOOP
        FETCH cur_transactions INTO v_customer_id, v_transaction_id, v_transaction_date, v_transaction_amount, v_transaction_type;
        EXIT WHEN cur_transactions%NOTFOUND;
        
        -- Print statement for each customer
        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || v_customer_id);
        DBMS_OUTPUT.PUT_LINE('Transaction ID: ' || v_transaction_id);
        DBMS_OUTPUT.PUT_LINE('Transaction Date: ' || v_transaction_date);
        DBMS_OUTPUT.PUT_LINE('Transaction Amount: ' || v_transaction_amount);
        DBMS_OUTPUT.PUT_LINE('Transaction Type: ' || v_transaction_type);
        DBMS_OUTPUT.PUT_LINE('--------------------------------------');
    END LOOP;
    CLOSE cur_transactions;
END;
/


-- Scenario 2: Apply Annual Fee to All Accounts

DECLARE
    CURSOR cur_accounts IS
        SELECT account_id, balance
        FROM accounts;
        
    v_account_id accounts.account_id%TYPE;
    v_balance accounts.balance%TYPE;
    v_annual_fee CONSTANT NUMBER := 50.00; -- Example annual fee
    
BEGIN
    OPEN cur_accounts;
    LOOP
        FETCH cur_accounts INTO v_account_id, v_balance;
        EXIT WHEN cur_accounts%NOTFOUND;
        
        -- Deduct the annual fee
        v_balance := v_balance - v_annual_fee;
        
        -- Update the account balance
        UPDATE accounts
        SET balance = v_balance
        WHERE account_id = v_account_id;
        
        DBMS_OUTPUT.PUT_LINE('Account ID: ' || v_account_id || ' - New Balance: ' || v_balance);
    END LOOP;
    CLOSE cur_accounts;
    
    COMMIT;
END;
/


-- Scenario 3: Update the Interest Rate for All Loans Based on a New Policy

DECLARE
    CURSOR cur_loans IS
        SELECT loan_id, interest_rate
        FROM loans;
        
    v_loan_id loans.loan_id%TYPE;
    v_interest_rate loans.interest_rate%TYPE;
    v_new_interest_rate CONSTANT NUMBER := 0.05; -- Example new interest rate (5%)
    
BEGIN
    OPEN cur_loans;
    LOOP
        FETCH cur_loans INTO v_loan_id, v_interest_rate;
        EXIT WHEN cur_loans%NOTFOUND;
        
        -- Update the interest rate based on the new policy
        v_interest_rate := v_new_interest_rate;
        
        -- Update the loan interest rate
        UPDATE loans
        SET interest_rate = v_interest_rate
        WHERE loan_id = v_loan_id;
        
        DBMS_OUTPUT.PUT_LINE('Loan ID: ' || v_loan_id || ' - New Interest Rate: ' || v_interest_rate);
    END LOOP;
    CLOSE cur_loans;
    
    COMMIT;
END;
/
