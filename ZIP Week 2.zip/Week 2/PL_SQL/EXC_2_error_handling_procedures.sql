-- Scenario 1: Handle Exceptions During Fund Transfers Between Accounts

CREATE OR REPLACE PROCEDURE SafeTransferFunds (
    p_from_account_id IN NUMBER,
    p_to_account_id IN NUMBER,
    p_amount IN NUMBER
) IS
    v_from_balance NUMBER;
    v_to_balance NUMBER;
BEGIN
    -- Fetch the balance of the from account
    SELECT balance INTO v_from_balance FROM accounts WHERE account_id = p_from_account_id FOR UPDATE;

    -- Check if there are sufficient funds
    IF v_from_balance < p_amount THEN
        RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds in the source account.');
    END IF;

    -- Fetch the balance of the to account
    SELECT balance INTO v_to_balance FROM accounts WHERE account_id = p_to_account_id FOR UPDATE;

    -- Perform the transfer
    UPDATE accounts SET balance = balance - p_amount WHERE account_id = p_from_account_id;
    UPDATE accounts SET balance = balance + p_amount WHERE account_id = p_to_account_id;

    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        INSERT INTO error_log (error_message, error_time)
        VALUES (SQLERRM, SYSDATE);
        RAISE;
END;
/

-- Scenario 2: Manage Errors When Updating Employee Salaries

CREATE OR REPLACE PROCEDURE UpdateSalary (
    p_employee_id IN NUMBER,
    p_percentage IN NUMBER
) IS
    v_current_salary NUMBER;
BEGIN
    -- Fetch the current salary of the employee
    SELECT salary INTO v_current_salary FROM employees WHERE employee_id = p_employee_id FOR UPDATE;

    -- Update the salary
    UPDATE employees
    SET salary = salary + (salary * p_percentage / 100)
    WHERE employee_id = p_employee_id;

    COMMIT;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        INSERT INTO error_log (error_message, error_time)
        VALUES ('Employee ID ' || p_employee_id || ' does not exist.', SYSDATE);
    WHEN OTHERS THEN
        ROLLBACK;
        INSERT INTO error_log (error_message, error_time)
        VALUES (SQLERRM, SYSDATE);
        RAISE;
END;
/


-- Scenario 3: Ensure Data Integrity When Adding a New Customer

CREATE OR REPLACE PROCEDURE AddNewCustomer (
    p_customer_id IN NUMBER,
    p_name IN VARCHAR2,
    p_age IN NUMBER,
    p_address IN VARCHAR2
) IS
BEGIN
    -- Insert the new customer
    INSERT INTO customers (customer_id, name, age, address)
    VALUES (p_customer_id, p_name, p_age, p_address);

    COMMIT;

EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        INSERT INTO error_log (error_message, error_time)
        VALUES ('Customer ID ' || p_customer_id || ' already exists.', SYSDATE);
    WHEN OTHERS THEN
        ROLLBACK;
        INSERT INTO error_log (error_message, error_time)
        VALUES (SQLERRM, SYSDATE);
        RAISE;
END;
/

