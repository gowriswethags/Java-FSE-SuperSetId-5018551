-- Scenario 1: Automatically Update the Last Modified Date

CREATE OR REPLACE TRIGGER UpdateCustomerLastModified
BEFORE UPDATE ON Customers
FOR EACH ROW
BEGIN
    :NEW.LastModified := SYSDATE;
END;
/


-- Scenario 2: Maintain an Audit Log for All Transactions

CREATE OR REPLACE TRIGGER LogTransaction
AFTER INSERT ON Transactions
FOR EACH ROW
BEGIN
    INSERT INTO AuditLog (transaction_id, transaction_date, transaction_amount, transaction_type)
    VALUES (:NEW.transaction_id, :NEW.transaction_date, :NEW.transaction_amount, :NEW.transaction_type);
END;
/


-- Scenario 3: Enforce Business Rules on Deposits and Withdrawals

CREATE OR REPLACE TRIGGER CheckTransactionRules
BEFORE INSERT ON Transactions
FOR EACH ROW
DECLARE
    v_balance NUMBER;
BEGIN
    IF :NEW.transaction_type = 'withdrawal' THEN
        SELECT balance INTO v_balance
        FROM accounts
        WHERE account_id = :NEW.account_id;

        IF :NEW.transaction_amount > v_balance THEN
            RAISE_APPLICATION_ERROR(-20001, 'Insufficient balance for withdrawal.');
        END IF;
    ELSIF :NEW.transaction_type = 'deposit' THEN
        IF :NEW.transaction_amount <= 0 THEN
            RAISE_APPLICATION_ERROR(-20002, 'Deposit amount must be positive.');
        END IF;
    END IF;
END;
/
